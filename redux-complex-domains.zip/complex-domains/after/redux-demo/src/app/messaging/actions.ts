export const INCREMENT = 'INCREMENT';
export const DECREMENT = 'DECREMENT'; 